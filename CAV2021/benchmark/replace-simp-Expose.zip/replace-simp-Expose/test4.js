
function fun(n)
{
	v = n.replace(/^[^.]*\.?/, '').length;
	if (v === 0)
	{
		console.log("1");
	}
	else
	{
		console.log("4");
	}
}


var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
