
function fun(stringValue)
{
  stringValue = stringValue.replace(/^'|'$/g, '"');
  if (!/^"/.test(stringValue)) {
    stringValue = '"' + stringValue + '"';
  }
}


var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
