
function fun(source)
{
   source = source.replace(/\\/g, "/").replace(/(\/(index)?)?(\.js)?$/, "").toLowerCase();
   if(/\\\\/.test(source)) console.log("1");
}


var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
