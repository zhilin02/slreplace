
function fun(p)
{
	var name = p.replace(/-[a-z]/g, (match) => { return match.toUpperCase(); });
	if(/[a-z]+/.test(name)) console.log("1");
}


var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
