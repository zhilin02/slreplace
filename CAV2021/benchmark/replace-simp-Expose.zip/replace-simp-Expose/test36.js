
function fun(elem)
{
	if(elem){
        	var snake_case = elem.replace(/[A-Z][^A-Z]/g, '_$&').toLowerCase();
        	if (/[A-Z]/.test(snake_case)) {
                	console.log("1");
				}
			}
}


var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
