
function fun(pattern)
{ 
  var gpattern = '';
  if (pattern.slice(-3) === '/**') {
    var gpattern = pattern.replace(/(\/\*\*)+$/, '');
  }
  if(gpattern!=='') console.log("1");
}


var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
