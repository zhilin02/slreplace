
function fun(relativePath)
{ 
	if(relativePath) {
		var stripped = relativePath.replace(/\/$/g, ''); 
		var result = '';
		if((/^((\.\.)|(\.))($|\/)/.test(stripped))){
			result = stripped;
  		}
  		else
  		{
			result =   './'+ stripped;
  		}
	}
}



var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
