
function fun(input)
{
    var result = '';
    if (input.match(/\[[\s\S]/)) {
        result = input.replace(/^\[|\]$/g, '');
    }
    result = input.replace(/\\/g, '');
    if(/\[/.test(result)) console.log("1");
}


var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
