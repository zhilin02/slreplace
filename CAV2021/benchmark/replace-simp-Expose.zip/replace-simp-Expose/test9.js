
function fun(url)
{
	if(url.replace(/^[\s]+|[\s]+$/g, '').length === 0)
	{
    		console.log("0");
	}
}


var S$ = require("S$");

var arg = S$.symbol("arg", "");
fun(arg);
