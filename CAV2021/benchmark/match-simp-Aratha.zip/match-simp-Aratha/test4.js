function test_match(obj){

    if(obj.match(/\s([a-z]+)/i)[1].toLowerCase()!=='') console.log("1");

}
var arg = J$.readString();
test_match(arg);
