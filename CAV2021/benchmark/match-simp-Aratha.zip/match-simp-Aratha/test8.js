function test_match(digitsInfo){
const NUMBER_FORMAT_REGEXP = /^(\d+)?\.((\d+)(-(\d+))?)?$/;
if (digitsInfo) {
      const parts = digitsInfo.match(NUMBER_FORMAT_REGEXP);
      if (parts){
            const minIntPart = parts[1];
            const minFractionPart = parts[3];
            const maxFractionPart = parts[5];
            if (minIntPart && minFractionPart && maxFractionPart) {
                console.log("1");
            }
        }
}
}
var arg = J$.readString();
test_match(arg);
