function test_match(opt){
	if(opt.match(/^(es|es6|es7|esnext|web)\./))
		target = "builtIns";
	else
		target = "plugins";

}
var arg = J$.readString();
test_match(arg);
