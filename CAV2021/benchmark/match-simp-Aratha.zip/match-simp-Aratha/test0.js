function test_match(name){
    var sanitizeRegex = /[^a-zA-Z0-9,-]/;

    if (name.match(/^(.+?)(?:-(.+?))?$/)[1].match(sanitizeRegex)) {
      throw new Error('Incorrectly formatted service names');
    }
}
var arg = J$.readString();
test_match(arg);
