function test_match(pattern){
  if (pattern === '/**') {
    var gpattern = pattern.replace(/(\/\*\*)+$/, '');
    if(pattern !== '') console.log("1");
  }
}
var arg = J$.readString();
test_match(arg);
