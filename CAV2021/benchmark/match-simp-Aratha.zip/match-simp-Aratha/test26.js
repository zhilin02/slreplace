function test_match(string){
const reAsciiWord = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g
var result = string.match(reAsciiWord);
if(result && result[0]!=='') console.log("1");
}
var arg = J$.readString();
test_match(arg);
