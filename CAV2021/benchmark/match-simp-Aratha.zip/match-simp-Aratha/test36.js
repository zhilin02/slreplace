function test_match(str){
const SEGMENT_RE = /^[^\/()?;=#]+/;
var match = str.match(SEGMENT_RE);
var result = '';
if(match)
{ 
	result = match[0];
	if(/\).*/.test(result)) console.log("1");
}

}
var arg = J$.readString();
test_match(arg);
