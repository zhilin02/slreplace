function test_match(fn){
if(fn)
{
  var match = fn.match(/^\s*function (\w+)/);
  var result = '';
  if(match) result = match[1];
  if(result!=='') console.log("1");
}
}
var arg = J$.readString();
test_match(arg);
