function test_match(currentGroup){
const regExpRegExp = /\/(.*)\/([gimsuy]*)/;
const isRegExp = currentGroup.match(regExpRegExp);
if (isRegExp) {
      const pattern = isRegExp[1], flag = isRegExp[2];
      if(flag !== '' && pattern !== '') console.log("1");
}
}
var arg = J$.readString();
test_match(arg);
