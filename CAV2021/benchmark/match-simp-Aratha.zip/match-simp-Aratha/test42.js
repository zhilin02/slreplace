function test_match(template){
        if (template !== 'production') {
          const leadingSpaceLength = template.match(/^\s*/)[0].length;
	  if(leadingSpaceLength>2) console.log("1");
        }
}
var arg = J$.readString();
test_match(arg);
