function test_match(value){
const BINDING_REGEXP = /(\d+):?\d*/;

var result = '';
if (value !== '') {
         var match = value.match(BINDING_REGEXP);
         if (match) {
		    result = match[1];
         }
}
}
var arg = J$.readString();
test_match(arg);
