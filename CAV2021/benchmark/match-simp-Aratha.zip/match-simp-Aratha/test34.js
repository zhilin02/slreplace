function test_match(source){

    var group = source.match(/\((?!\?)/);
    if (group[0]!=='(') {
	console.log("0");
    }

}
var arg = J$.readString();
test_match(arg);
