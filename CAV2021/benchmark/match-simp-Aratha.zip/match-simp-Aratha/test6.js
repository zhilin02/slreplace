function test_match(chunk){
const STRING_REGEX = /^(['"])((?:\\.|(?!\1)[^\\])*)\1$/;
const ESCAPE_REGEX = /\\(u(?:[a-f\d]{4}|{[a-f\d]{1,6}})|x[a-f\d]{2}|.)|([^\\])/gi;

var result = '';
if ((matches = chunk.match(STRING_REGEX))) {	
	result = matches[2].replace(ESCAPE_REGEX, '');
	if(result !== '') console.log("1");
}

}
var arg = J$.readString();
test_match(arg);
