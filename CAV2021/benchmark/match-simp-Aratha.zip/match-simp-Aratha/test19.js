function test_match(line){
                const lineOffset = line.match(/^(\s*\*?\s*)/u)[1];
                if (lineOffset) {
			console.log("1");
                    }

}
var arg = J$.readString();
test_match(arg);
