function test_match(constructorFn){
var functionNameMatch = /\s*function(?:\s|\s*\/\*[^(?:*\/)]+\*\/\s*)*([^\(\/]+)/;
  var name = '';
  var match = constructorFn.match(functionNameMatch);
    if (match) {
      name = match[1];
    }
   else {
    name = '';
  }
  if(name !== '') console.log("1");

}
var arg = J$.readString();
test_match(arg);
