function test_match(string){
            const trailingWhitespace = string.match(/\s*$/u)[0];
	    if(trailingWhitespace!="") console.log("1");
}
var arg = J$.readString();
test_match(arg);
