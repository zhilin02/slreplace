function test_match(text){
        var out = '';
        if (text) {
            if (text.match(/\/\*|\*\//)) {
                throw new Error('JSDoc text cannot contain "/*" and "*/"');
            }
            out += ' ' + text.replace(/@/g, '\\@');
        }
        if(out!== '') console.log("1");
}
var arg = J$.readString();
test_match(arg);
