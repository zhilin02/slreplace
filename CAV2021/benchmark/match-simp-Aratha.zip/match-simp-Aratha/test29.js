function test_match(chunk){
var chunkOffset = /([\+\-]|\d\d)/gi;
parts = chunk.match(chunkOffset);
if(parts[1] == '11') console.log("1");
}
var arg = J$.readString();
test_match(arg);
