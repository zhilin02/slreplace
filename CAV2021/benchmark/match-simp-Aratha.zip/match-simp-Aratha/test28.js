function test_match(input){
 var result = '';
   if (input.match(/\[[\s\S]/)) {
        result = input.replace(/^\[|\]$/g, '');
    }
    else result = input.replace(/\\/g, '');
   if(result !='') console.log("1");
}
var arg = J$.readString();
test_match(arg);
