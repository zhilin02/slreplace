function test_match(bindingName){
const ATTR_REGEX = /attr\.([^\]]+)/;
const attrMatches = bindingName.match(ATTR_REGEX);
if (attrMatches) {
     bindingName = attrMatches[1];
}
if(bindingName!=='') console.log("1");

}
var arg = J$.readString();
test_match(arg);
