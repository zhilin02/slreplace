function test_match(attempt){
      var match = attempt.match(/\.[^<>:"/\|?*.]+$/);
      if (match && match[0].length >= 2) {
	console.log("1"); 	
      }

}
var arg = J$.readString();
test_match(arg);
