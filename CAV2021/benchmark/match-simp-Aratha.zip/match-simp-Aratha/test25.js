function test_match(value){
const rnothtmlwhite = /[^\x20\t\r\n\f]+/;
var result = value.match(rnothtmlwhite);
if(result){
  if(result[0]!=='') console.log("1");
}

}
var arg = J$.readString();
test_match(arg);
