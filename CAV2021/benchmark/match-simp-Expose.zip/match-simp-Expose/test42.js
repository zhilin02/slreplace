function test_match(template){
        if (template !== 'production') {
          const leadingSpaceLength = template.match(/^\s*/)[0].length;
	  if(leadingSpaceLength>2) console.log("1");
        }
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
