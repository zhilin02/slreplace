function test_match(input){
 var result = '';
   if (input.match(/\[[\s\S]/)) {
        result = input.replace(/^\[|\]$/g, '');
    }
    else result = input.replace(/\\/g, '');
   if(result !='') console.log("1");
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
