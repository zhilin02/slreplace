function test_match(opt){
	if(opt.match(/^(es|es6|es7|esnext|web)\./))
		target = "builtIns";
	else
		target = "plugins";

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
