function test_match(str){

  var match = str.match(/^\s*(\d*)\s*(.*)$/);
  if(match) {
	var result = "num:" + match[1] + "value:" + match[2];
	if(/value:\d+/.test(result)) console.log("1");
	}
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
