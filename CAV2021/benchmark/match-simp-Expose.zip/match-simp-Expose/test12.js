function test_match(name){
const BIND_NAME_REGEXP =
    /^(?:(?:(?:(bind-)|(let-)|(ref-|#)|(on-)|(bindon-)|(@))(.*))|\[\(([^\)]+)\)\]|\[([^\]]+)\]|\(([^\)]+)\))$/;

// Group 1 = "bind-"
const KW_BIND_IDX = 1;
// Group 2 = "let-"
const KW_LET_IDX = 2;
// Group 3 = "ref-/#"
const KW_REF_IDX = 3;
// Group 4 = "on-"
const KW_ON_IDX = 4;
// Group 5 = "bindon-"
const KW_BINDON_IDX = 5;
// Group 6 = "@"
const KW_AT_IDX = 6;
// Group 7 = the identifier after "bind-", "let-", "ref-/#", "on-", "bindon-" or "@"
const IDENT_KW_IDX = 7;
// Group 8 = identifier inside [()]
const IDENT_BANANA_BOX_IDX = 8;
// Group 9 = identifier inside []
const IDENT_PROPERTY_IDX = 9;
// Group 10 = identifier inside ()
const IDENT_EVENT_IDX = 10;

        const bindParts = name.match(BIND_NAME_REGEXP);
        let hasBinding = false;
        if (bindParts !== null) {
            hasBinding = true;
            if (bindParts[KW_BIND_IDX] != null) {
                console.log(KW_BIND_IDX);
            }
            else if (bindParts[KW_LET_IDX]) {
                    console.log(KW_LET_IDX);
            }
            else if (bindParts[KW_REF_IDX]) {
                console.log(KW_REF_IDX);
            }
            else if (bindParts[KW_ON_IDX]) {
                console.log(KW_ON_IDX);
            }
            else if (bindParts[KW_BINDON_IDX]) {
                console.log(KW_BINDON_IDX);
            }
            else if (bindParts[KW_AT_IDX]) {
                console.log(KW_AT_IDX);
            }
            else if (bindParts[IDENT_BANANA_BOX_IDX]) {
		console.log(IDENT_BANANA_BOX_IDX);
            }
            else if (bindParts[IDENT_PROPERTY_IDX]) {
                console.log(IDENT_PROPERTY_IDX);
            }
            else if (bindParts[IDENT_EVENT_IDX]) {
                console.log(IDENT_EVENT_IDX);
            }
        }

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
