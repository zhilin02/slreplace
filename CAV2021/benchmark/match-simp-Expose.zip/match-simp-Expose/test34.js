function test_match(source){

    var group = source.match(/\((?!\?)/);
    if (group[0]!=='(') {
	console.log("0");
    }

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
