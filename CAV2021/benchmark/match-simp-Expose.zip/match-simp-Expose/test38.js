function test_match(attempt){
      var match = attempt.match(/\.[^<>:"/\|?*.]+$/);
      if (match && match[0].length >= 2) {
	console.log("1"); 	
      }

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
