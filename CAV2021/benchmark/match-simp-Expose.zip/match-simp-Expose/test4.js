function test_match(obj){

    if(obj.match(/\s([a-z]+)/i)[1].toLowerCase()!=='') console.log("1");

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
