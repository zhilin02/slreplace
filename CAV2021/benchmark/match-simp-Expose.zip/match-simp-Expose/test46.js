function test_match(str){
var result = '';
if (str.match(/^v\-/)) {
    result = str.replace(/(v-[a-z\-]+\:)([a-z\-]+)$/i, ($, directive, prop) => {
      return directive + '#' + prop;
    })
    if(/[A-Z]+/.test(result)) console.log("1");
  }
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
