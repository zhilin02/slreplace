function test_match(chunk){
var chunkOffset = /([\+\-]|\d\d)/gi;
parts = chunk.match(chunkOffset);
if(parts[1] == '11') console.log("1");
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
