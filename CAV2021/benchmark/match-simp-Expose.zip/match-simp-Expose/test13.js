function test_match(uri){

const _splitRe = /^(?:([^:/?#.]+):)?(?:\/(?:([^/?#]*)@)?([\\w\\d\\-\\u0100-\\uffff.%]*)(?::([0-9]+))?)?([^?#]+)?(?:\\?([^#]*))?(?:#(.*))?$/; 

var result = uri.match(_splitRe);

if(result && result[1] !== '') console.log("1");
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
