function test_match(str){
  const regex = new RegExp('.{1,' + (width - 1) + '}([\\s\u200B]|$)|[^\\s\u200B]+?([\\s\u200B]|$)');
  const line = str.match(regex) || [];
    if (line === '\n') {
      console.log(1);
    }

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
