function test_match(name){
const dirRE = /^v-|^@|^:|^\.|^#/;
const argRE = /:(.*)$/;
const dynamicArgRE = /^\[.*\]$/;
name = name.replace(dirRE, '');
const argMatch = name.match(argRE);
let arg = argMatch && argMatch[1];
isDynamic = false;
if (arg) {
     name = name.slice(0, -(arg.length + 1));
     if (name!=='' && dynamicArgRE.test(arg)) {
       arg = arg.slice(1, -1);
       isDynamic = true;
     }
}

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
