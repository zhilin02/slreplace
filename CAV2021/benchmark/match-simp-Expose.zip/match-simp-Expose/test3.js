function test_match(line){

var nodeFramePattern = /\((?:timers\.js):\d+:\d+\)/;
var parseLinePattern = /[\/<\(](.+?):(\d+):(\d+)\)?\s*$/;

if (!nodeFramePattern.test(line)) {
	var lineMatches = line.match(parseLinePattern);
        if (lineMatches) {
              handlerLine  = "at " + lineMatches[1] +
                 ":" + lineMatches[2] + ":" + lineMatches[3] + " ";
	      if(handlerLine!=='') console.log("1");
        }
}

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
