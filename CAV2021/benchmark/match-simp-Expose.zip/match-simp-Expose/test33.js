function test_match(path){
const BEFORE_SLASH_RE = /^(.*)[\\\/]/;
var fileName = path.replace(BEFORE_SLASH_RE, '');
if (/^index\./.test(fileName)) {
   var match = path.match(BEFORE_SLASH_RE);
   if (match) {
      var pathBeforeSlash = match[1];
      if (pathBeforeSlash) {
         var folderName = pathBeforeSlash.replace(BEFORE_SLASH_RE, '');
            fileName = folderName + '/' + fileName;
	    if(/[A-Za-Z].*/.test(fileName)) console.log("1");
          }
    }
}

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
