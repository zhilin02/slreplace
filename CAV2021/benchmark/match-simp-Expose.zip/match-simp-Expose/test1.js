function test_match(changelog){

var versionMarkerReg = /<!--LATEST=(\\d+)\\.(\\d+)\\.(\\d+)-->/;

var result = '';
if (changelog)
{
	var match = changelog.match(versionMarkerReg);
	if(match)
	{
		result = 'major:' + match[1] + 'minor:' + match[2] + 'patch:' + match[3];
		if(result!=='') console.log("1"); 
	}
	
}
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
