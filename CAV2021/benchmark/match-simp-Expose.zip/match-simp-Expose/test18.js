function test_match(string){
            const trailingWhitespace = string.match(/\s*$/u)[0];
	    if(trailingWhitespace!="") console.log("1");
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
