function test_match(currentGroup){
const regExpRegExp = /\/(.*)\/([gimsuy]*)/;
const isRegExp = currentGroup.match(regExpRegExp);
if (isRegExp) {
      const pattern = isRegExp[1], flag = isRegExp[2];
      if(flag !== '' && pattern !== '') console.log("1");
}
}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
