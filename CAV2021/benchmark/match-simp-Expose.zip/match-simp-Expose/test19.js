function test_match(line){
                const lineOffset = line.match(/^(\s*\*?\s*)/u)[1];
                if (lineOffset) {
			console.log("1");
                    }

}
var S$ = require("S$");

var arg = S$.symbol("arg", "");
test_match(arg);
