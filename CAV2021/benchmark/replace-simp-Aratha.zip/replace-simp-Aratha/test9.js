
function fun(url)
{
	if(url.replace(/^[\s]+|[\s]+$/g, '').length === 0)
	{
    		console.log("0");
	}
}


var arg = J$.readString();
fun(arg);
