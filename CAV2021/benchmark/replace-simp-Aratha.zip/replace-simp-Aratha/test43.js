
function fun(cmd)
{
    const bregex = /\.*[\][<>]/g;
    cmd = cmd.replace(bregex, '');
    if(/<>/.test(cmd)) console.log("0");
}



var arg = J$.readString();
fun(arg);
