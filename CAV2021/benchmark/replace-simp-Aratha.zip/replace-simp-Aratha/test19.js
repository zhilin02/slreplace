
function fun(relativePath)
{ 
	if(relativePath) {
		var stripped = relativePath.replace(/\/$/g, ''); 
		var result = '';
		if((/^((\.\.)|(\.))($|\/)/.test(stripped))){
			result = stripped;
  		}
  		else
  		{
			result =   './'+ stripped;
  		}
	}
}



var arg = J$.readString();
fun(arg);
