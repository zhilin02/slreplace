
function fun(stringValue)
{
  stringValue = stringValue.replace(/^'|'$/g, '"');
  if (!/^"/.test(stringValue)) {
    stringValue = '"' + stringValue + '"';
  }
}


var arg = J$.readString();
fun(arg);
