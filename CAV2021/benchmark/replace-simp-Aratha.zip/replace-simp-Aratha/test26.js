
function fun(input)
{
    var result = '';
    if (input.match(/\[[\s\S]/)) {
        result = input.replace(/^\[|\]$/g, '');
    }
    result = input.replace(/\\/g, '');
    if(/\[/.test(result)) console.log("1");
}


var arg = J$.readString();
fun(arg);
