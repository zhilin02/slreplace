
function fun(p)
{
	var name = p.replace(/-[a-z]/g, (match) => { return match.toUpperCase(); });
	if(/[a-z]+/.test(name)) console.log("1");
}


var arg = J$.readString();
fun(arg);
