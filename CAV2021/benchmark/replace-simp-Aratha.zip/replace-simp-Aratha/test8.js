
function fun(BANNER)
{
	BANNER = BANNER.replace(/\[\d+m/g, '');
	if(/\d+/.test(BANNER)) console.log("0");
}


var arg = J$.readString();
fun(arg);
