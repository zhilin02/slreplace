
function fun(elem)
{
	if(elem){
        	var snake_case = elem.replace(/[A-Z][^A-Z]/g, '_$&').toLowerCase();
        	if (/[A-Z]/.test(snake_case)) {
                	console.log("1");
				}
			}
}


var arg = J$.readString();
fun(arg);
