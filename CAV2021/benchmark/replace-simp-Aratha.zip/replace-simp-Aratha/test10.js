
function fun(localident)
{
	const filenameReservedRegex = /[<>:"/\\|?*]/g;
	const reControlChars = /[\u0000-\u001f\u0080-\u009f]/g;
	localident = localident.replace(/^((-?[0-9])|--)/, "_$1").replace(filenameReservedRegex, "-").replace(reControlChars, "-").replace(/\./g, "-");
	if(/</.test(localident)) console.log("0");
}


var arg = J$.readString();
fun(arg);
