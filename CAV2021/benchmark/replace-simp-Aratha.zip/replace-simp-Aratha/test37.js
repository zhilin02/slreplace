
function fun(hostname)
{
  	var result = hostname.replace(/^\.*/, '.');
	if(/\.\./.test(result)) console.log("0");
}


var arg = J$.readString();
fun(arg);
