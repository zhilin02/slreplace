
function fun(n)
{
	v = n.replace(/^[^.]*\.?/, '').length;
	if (v === 0)
	{
		console.log("1");
	}
	else
	{
		console.log("4");
	}
}


var arg = J$.readString();
fun(arg);
