
function fun(comment)
{
	const DEFAULT_IGNORE_PATTERN = /^\s*(?:eslint|jshint\s+|jslint\s+|istanbul\s+|globals?\s+|exported\s+|jscs)/;
	const MAYBE_URL = /^\s*[^:/?#\s]+:\/\/[^?#]/; 
	var commentWithoutAsterisks = comment.replace(/\*/g, "");
	if (DEFAULT_IGNORE_PATTERN.test(commentWithoutAsterisks)){
                console.log("1");
	}
	if (MAYBE_URL.test(commentWithoutAsterisks)) {
                console.log("0");
	}
}


var arg = J$.readString();
fun(arg);
