

function fun(base)
{
      base = base.replace(/^https?:\/\/[^\/]+/, '');
  if (base.charAt(0) !== '/') {
    base = '/' + base
}
}


var arg = J$.readString();
fun(arg);
