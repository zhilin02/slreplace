
function fun(source)
{
   source = source.replace(/\\/g, "/").replace(/(\/(index)?)?(\.js)?$/, "").toLowerCase();
   if(/\\\\/.test(source)) console.log("1");
}


var arg = J$.readString();
fun(arg);
