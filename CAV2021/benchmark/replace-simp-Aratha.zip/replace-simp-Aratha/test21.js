
function fun(value)
{ 
	var result = value.replace(/^.*\.propTypes\./, '');
	if(/propTypes/.test(result)) console.log("0");
}


var arg = J$.readString();
fun(arg);
