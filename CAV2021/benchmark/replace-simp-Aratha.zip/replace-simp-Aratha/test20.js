
function fun(replacementText)
{ 
       if (replacementText === 'start') {
        replacementText = replacementText.replace(/^\s+/g, '') + ' ';
      } else {
        replacementText = ' ' + replacementText.replace(/\s+$/g, '');
      }
	if(/\s\s$/.test(replacementText)) console.log("0");
}


var arg = J$.readString();
fun(arg);
