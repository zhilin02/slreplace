
function fun(str)
{
  	str = str.replace(/;(\s*$)/, '$1');
	if(/;/.test(str)) console.log("0");
}


var arg = J$.readString();
fun(arg);
