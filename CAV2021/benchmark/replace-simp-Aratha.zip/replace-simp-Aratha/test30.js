
function fun(path)
{
  var result = '';
  if (!/\.\d+/.test(path)) {
    result = path;
  }
  result = path.replace(/\.\d+\./g, '.$.').replace(/\.\d+$/, '.$');
  if(/\$\$/.test(result)) console.log("1");
}


var arg = J$.readString();
fun(arg);
